import os


class Config:
    # IMPORTANT: Set SECRET_KEY via environment variable in production!
    # Generate: python -c "import secrets; print(secrets.token_hex(32))"
    SECRET_KEY = os.environ.get('SECRET_KEY', 'CHANGE_ME_IN_PRODUCTION_SET_ENV_VAR')

    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL', "sqlite:///../instance/app.db")
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Set SESSION_COOKIE_SECURE=true in production (HTTPS only)
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
