/**
 * Anti-cheat system for control work (КР).
 * All critical enforcement is server-side.
 * This script tracks events and reports them; the server decides the outcome.
 */
(function () {
    'use strict';

    var CFG = window.ANTICHEAT_CONFIG || {};
    if (!CFG.isTest) return;

    var attemptId          = CFG.attemptId  || 0;
    var durationMinutes    = CFG.duration   || 0;
    // remainingTime comes from the SERVER at page load — never from localStorage
    var initialRemaining   = (typeof CFG.remainingTime === 'number') ? CFG.remainingTime : null;
    var serverStartMs      = CFG.serverStartMs || Date.now();
    var csrfToken          = CFG.csrfToken || '';

    var TAB_DEBOUNCE_MS  = 3000;
    var HEARTBEAT_MS     = 5000;

    var state = {
        tabSwitches:       0,
        copy:              false,
        fullscreenExits:   0,
        timeRemaining:     0,
        timerInterval:     null,
        trackingReady:     false,
        lastTabSwitchMs:   0
    };

    /* ── Timer ──────────────────────────────────────────────── */

    function calcRemaining() {
        // Always compute from server-provided start time — localStorage is NOT used
        if (initialRemaining !== null) {
            var elapsed = Math.floor((Date.now() - serverStartMs) / 1000);
            return Math.max(0, initialRemaining - elapsed);
        }
        if (durationMinutes > 0) {
            var elapsed2 = Math.floor((Date.now() - serverStartMs) / 1000);
            return Math.max(0, durationMinutes * 60 - elapsed2);
        }
        return null;
    }

    function formatTime(secs) {
        var m = Math.floor(secs / 60);
        var s = secs % 60;
        return (m < 10 ? '0' : '') + m + ':' + (s < 10 ? '0' : '') + s;
    }

    function updateTimerUI() {
        var box  = document.getElementById('timerBox');
        var span = document.getElementById('timeRemaining');
        if (!box || !span) return;
        box.style.display = 'block';
        span.textContent = formatTime(state.timeRemaining);
        if (state.timeRemaining <= 60) {
            box.classList.add('warning');
        } else {
            box.classList.remove('warning');
        }
    }

    function onTimerExpired() {
        clearInterval(state.timerInterval);
        state.timerInterval = null;
        // Submit via form POST with CSRF token — server will verify time again
        var form = document.getElementById('quizForm');
        if (!form) return;
        // Append violation fields
        appendHidden(form, 'violation_tab_switch', state.tabSwitches);
        appendHidden(form, 'violation_copy', state.copy ? '1' : '0');
        appendHidden(form, 'violation_fullscreen_exit', state.fullscreenExits);
        // Change action to auto-finish endpoint
        form.action = '/auto-finish/' + attemptId;
        alert('Время вышло! Работа будет завершена автоматически.');
        form.submit();
    }

    function startTimer() {
        var rem = calcRemaining();
        if (rem === null) return;
        state.timeRemaining = rem;
        updateTimerUI();

        if (rem === 0) { onTimerExpired(); return; }

        state.timerInterval = setInterval(function () {
            state.timeRemaining = calcRemaining();
            if (state.timeRemaining === null) { clearInterval(state.timerInterval); return; }
            updateTimerUI();
            if (state.timeRemaining <= 0) { onTimerExpired(); }
        }, 1000);
    }

    /* ── Heartbeat ──────────────────────────────────────────── */

    function sendHeartbeat() {
        fetch('/anticheat-heartbeat/' + attemptId, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-Token': csrfToken
            },
            body: JSON.stringify({
                t: state.tabSwitches,
                c: state.copy ? 1 : 0,
                f: state.fullscreenExits
            })
        }).then(function (r) { return r.json(); })
          .then(function (data) {
              if (data.status === 'expired') { onTimerExpired(); }
          })
          .catch(function () {});
    }

    var heartbeatTimer = setInterval(sendHeartbeat, HEARTBEAT_MS);

    /* ── Tracking activation (delay to avoid false positives) ── */

    var trackingTimer = setTimeout(function () {
        state.trackingReady = true;
    }, 2000);

    function activateNow() {
        clearTimeout(trackingTimer);
        state.trackingReady = true;
    }

    document.addEventListener('click',   activateNow, { once: true });
    document.addEventListener('keydown', activateNow, { once: true });

    /* ── Tab / window switch tracking ──────────────────────── */

    document.addEventListener('visibilitychange', function () {
        if (!state.trackingReady || !document.hidden) return;
        var now = Date.now();
        if (now - state.lastTabSwitchMs > TAB_DEBOUNCE_MS) {
            state.tabSwitches++;
            state.lastTabSwitchMs = now;
            updateViolationsUI();
            sendHeartbeat();
        }
    });

    window.addEventListener('blur', function () {
        if (!state.trackingReady || document.hidden) return;
        var now = Date.now();
        if (now - state.lastTabSwitchMs > TAB_DEBOUNCE_MS) {
            state.tabSwitches++;
            state.lastTabSwitchMs = now;
            updateViolationsUI();
            sendHeartbeat();
        }
    });

    /* ── Copy / cut tracking ────────────────────────────────── */

    document.addEventListener('copy', function () {
        if (!state.trackingReady || state.copy) return;
        state.copy = true;
        showFlash('⚠️ Обнаружено копирование!');
        sendHeartbeat();
    });

    document.addEventListener('cut', function () {
        if (!state.trackingReady || state.copy) return;
        state.copy = true;
        showFlash('⚠️ Обнаружено вырезание текста!');
        sendHeartbeat();
    });

    /* ── Fullscreen tracking ────────────────────────────────── */

    function onFullscreenChange() {
        var inFs = !!(document.fullscreenElement || document.webkitFullscreenElement);
        if (!inFs && state.trackingReady) {
            var now = Date.now();
            if (now - state.lastTabSwitchMs > TAB_DEBOUNCE_MS) {
                state.fullscreenExits++;
                state.lastTabSwitchMs = now;
                sendHeartbeat();
            }
        }
    }

    document.addEventListener('fullscreenchange',       onFullscreenChange);
    document.addEventListener('webkitfullscreenchange', onFullscreenChange);

    /* ── Hotkey blocking ────────────────────────────────────── */

    document.addEventListener('keydown', function (e) {
        var k = (e.key || '').toLowerCase();
        var blocked =
            k === 'f12' ||
            ((e.ctrlKey || e.metaKey) && e.shiftKey && (k === 'i' || k === 'j' || k === 'c')) ||
            ((e.ctrlKey || e.metaKey) && (k === 'u' || k === 's' || k === 'p')) ||
            k === 'printscreen' ||
            (e.metaKey && e.shiftKey && (k === '3' || k === '4' || k === '5' || k === 's'));

        if (blocked) {
            e.preventDefault();
            e.stopPropagation();
        }
    }, true);

    /* ── Context menu ───────────────────────────────────────── */

    document.addEventListener('contextmenu', function (e) { e.preventDefault(); });

    /* ── Text selection ─────────────────────────────────────── */

    document.body.style.userSelect         = 'none';
    document.body.style.webkitUserSelect   = 'none';

    /* ── Fullscreen request ─────────────────────────────────── */

    setTimeout(function () {
        var el = document.documentElement;
        if (el.requestFullscreen)            el.requestFullscreen().catch(function(){});
        else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    }, 800);

    /* ── Print detection ────────────────────────────────────── */

    window.addEventListener('beforeprint', function () {
        state.tabSwitches++;
        sendHeartbeat();
    });

    /* ── UI helpers ─────────────────────────────────────────── */

    function updateViolationsUI() {
        var panel = document.getElementById('violationsPanel');
        if (!panel) return;
        var total = state.tabSwitches;
        if (total > 0) {
            panel.style.display = 'block';
            panel.textContent = '⚠️ Нарушения: ' + total + ' переключений вкладок' +
                (state.copy ? ' + копирование' : '');
        }
    }

    function showFlash(msg) {
        var panel = document.getElementById('violationsPanel');
        if (!panel) return;
        panel.style.display = 'block';
        var orig = panel.textContent;
        panel.textContent = msg;
        setTimeout(function () { updateViolationsUI(); }, 2000);
    }

    function appendHidden(form, name, value) {
        var el = document.createElement('input');
        el.type  = 'hidden';
        el.name  = name;
        el.value = String(value);
        form.appendChild(el);
    }

    /* ── Form submit ────────────────────────────────────────── */

    var form = document.getElementById('quizForm');
    if (form) {
        form.addEventListener('submit', function () {
            appendHidden(form, 'violation_tab_switch',      state.tabSwitches);
            appendHidden(form, 'violation_copy',            state.copy ? '1' : '0');
            appendHidden(form, 'violation_fullscreen_exit', state.fullscreenExits);
            clearInterval(state.timerInterval);
            clearInterval(heartbeatTimer);
        }, true);
    }

    /* ── Beforeunload guard ─────────────────────────────────── */

    window.addEventListener('beforeunload', function (e) {
        if (state.trackingReady && state.timeRemaining > 0) {
            var msg = 'Вы уверены? Прогресс может быть потерян.';
            e.returnValue = msg;
            return msg;
        }
    });

    startTimer();

}());
