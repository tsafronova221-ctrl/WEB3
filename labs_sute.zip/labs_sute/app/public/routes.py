import random

from flask import (
    Blueprint, render_template, request, redirect, url_for,
    jsonify, session, abort
)
from app import db
from app.models import (
    Student, Group, Lab, LabFile, Question,
    Attempt, Answer, LabPassword, FileQuestionAnswer,
)
from app.security import generate_watermark_hash
from app.csrf import generate_csrf_token, validate_csrf_token
from datetime import datetime
import pytz

MSK = pytz.timezone('Europe/Moscow')
public_bp = Blueprint("public", __name__)


def _localize(dt):
    if dt is None:
        return None
    return MSK.localize(dt) if dt.tzinfo is None else dt


def _check_time_expired(attempt, lab):
    """Server-authoritative time check. Returns (expired, remaining_seconds)."""
    if not lab.is_test or not lab.test_duration or lab.test_duration <= 0:
        return False, None
    now = datetime.now(MSK)
    started = _localize(attempt.started_at)
    elapsed = (now - started).total_seconds()
    max_secs = lab.test_duration * 60
    remaining = int(max_secs - elapsed)
    return remaining <= 0, max(0, remaining)


def _ordered_questions(attempt):
    question_map = {a.question_id: a.question for a in attempt.answers}
    return [question_map[a.question_id] for a in attempt.answers
            if a.question_id in question_map]


# ---------------------------------------------------------------------------
# Anticheat heartbeat
# ---------------------------------------------------------------------------
@public_bp.route("/anticheat-heartbeat/<int:attempt_id>", methods=["POST"])
def anticheat_heartbeat(attempt_id):
    # Only the owner of this attempt may send heartbeats
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)
    if attempt.finished_at is not None:
        return jsonify({'status': 'ignored', 'reason': 'attempt_finished'})

    # Auto-close if server says time expired
    expired, _ = _check_time_expired(attempt, attempt.lab)
    if expired:
        attempt.finished_at = datetime.now(MSK)
        attempt.score = attempt.score or 0
        attempt.watermark_hash = generate_watermark_hash(attempt)
        db.session.commit()
        session.pop('active_attempt_id', None)
        return jsonify({'status': 'expired'})

    data = request.get_json() or {}
    if attempt.lab.is_test:
        attempt.violation_tab_switch = max(attempt.violation_tab_switch or 0, data.get('t', 0))
        attempt.violation_copy = attempt.violation_copy or (data.get('c', 0) == 1)
        attempt.violation_fullscreen_exit = max(attempt.violation_fullscreen_exit or 0, data.get('f', 0))
        db.session.commit()

    return jsonify({'status': 'ok', 'timestamp': datetime.now(MSK).isoformat()})


# ---------------------------------------------------------------------------
# Index
# ---------------------------------------------------------------------------
@public_bp.route("/")
def index():
    groups = Group.query.all()
    return render_template("public/index.html", groups=groups,
                           csrf_token=generate_csrf_token())


# ---------------------------------------------------------------------------
# Start attempt
# ---------------------------------------------------------------------------
@public_bp.route("/start", methods=["POST"])
def start():
    if not validate_csrf_token():
        abort(403)

    last = request.form.get("last_name", "").strip()
    first = request.form.get("first_name", "").strip()
    group_id = request.form.get("group_id", "").strip()
    password = request.form.get("password", "").strip().upper()

    all_groups = Group.query.all()

    def err(msg):
        return render_template("public/index.html", groups=all_groups,
                               error=msg, csrf_token=generate_csrf_token())

    if not last or not first or not password:
        return err("Заполните все поля")

    lp = LabPassword.query.filter_by(password=password).first()
    if not lp:
        return err("Неверный пароль варианта")

    lab = Lab.query.get(lp.lab_id)

    if group_id:
        try:
            selected_group_id = int(group_id)
        except ValueError:
            abort(400)
        if selected_group_id not in [g.id for g in lab.groups]:
            return err("Эта работа недоступна для выбранной группы")

    now = datetime.now(MSK)
    start_at = _localize(lab.start_at)
    deadline_at = _localize(lab.deadline_at)

    if start_at and start_at > now:
        return err("Время выполнения работы ещё не наступило")
    if deadline_at and now > deadline_at:
        return err("Срок сдачи работы истёк")

    student_q = Student.query.filter_by(last_name=last, first_name=first)
    if group_id:
        student_q = student_q.filter_by(group_id=int(group_id))
    student = student_q.first()
    if not student:
        student = Student(last_name=last, first_name=first,
                          group_id=int(group_id) if group_id else None)
        db.session.add(student)
        db.session.commit()

    existing = Attempt.query.filter_by(
        student_id=student.id, lab_id=lab.id, password_id=lp.id
    ).first()

    if existing:
        if existing.finished_at is not None:
            return err("Вы уже выполняли эту работу. Повторная попытка невозможна.")

        started = _localize(existing.started_at)
        if (now - started).total_seconds() > 24 * 3600:
            db.session.delete(existing)
            db.session.commit()
            existing = None
        else:
            expired, remaining = _check_time_expired(existing, lab)
            if expired:
                existing.finished_at = now
                existing.score = 0
                existing.watermark_hash = generate_watermark_hash(existing)
                db.session.commit()
                return err("Время на выполнение работы истекло. Повторная попытка невозможна.")

            lab_file = LabFile.query.get(lp.file_id)
            questions = _ordered_questions(existing)
            session['active_attempt_id'] = existing.id
            kwargs = dict(attempt=existing, lab_file=lab_file,
                          questions=questions, lab=lab,
                          csrf_token=generate_csrf_token())
            if remaining is not None:
                kwargs['remaining_time'] = remaining
            return render_template("public/questions.html", **kwargs)

    # Create new attempt
    lab_file = LabFile.query.get(lp.file_id)
    attempt = Attempt(
        student_id=student.id,
        lab_id=lab.id,
        password_id=lp.id,
        ip=request.remote_addr,
        user_agent=request.headers.get("User-Agent", "")[:256],
        started_at=datetime.now(MSK),
    )
    db.session.add(attempt)
    db.session.flush()

    all_questions = Question.query.filter_by(lab_id=lab.id).all()
    if lab.is_test and lab.questions_count and lab.questions_count > 0:
        selected = random.sample(all_questions, min(len(all_questions), lab.questions_count))
    else:
        selected = all_questions

    for q in selected:
        db.session.add(Answer(attempt_id=attempt.id, question_id=q.id,
                              answer_text="", is_correct=False))
    db.session.commit()

    session['active_attempt_id'] = attempt.id

    kwargs = dict(attempt=attempt, lab_file=lab_file,
                  questions=selected, lab=lab,
                  csrf_token=generate_csrf_token())
    if lab.is_test and lab.test_duration:
        kwargs['remaining_time'] = lab.test_duration * 60
    return render_template("public/questions.html", **kwargs)


# ---------------------------------------------------------------------------
# Finish attempt
# ---------------------------------------------------------------------------
@public_bp.route("/finish/<int:attempt_id>", methods=["POST"])
def finish(attempt_id):
    if not validate_csrf_token():
        abort(403)
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)

    if attempt.finished_at is not None:
        results = [['neutral', a.question.text] for a in attempt.answers]
        return render_template("public/finish.html", attempt=attempt, answers=results)

    # Server enforces time limit
    expired, _ = _check_time_expired(attempt, attempt.lab)
    if expired:
        attempt.finished_at = datetime.now(MSK)
        attempt.score = 0
        attempt.watermark_hash = generate_watermark_hash(attempt)
        db.session.commit()
        session.pop('active_attempt_id', None)
        results = [['neutral', a.question.text] for a in attempt.answers]
        return render_template("public/finish.html", attempt=attempt, answers=results)

    if attempt.lab.is_test:
        tab_f = request.form.get('violation_tab_switch', 0, type=int)
        copy_f = request.form.get('violation_copy', '0') == '1'
        fs_f = request.form.get('violation_fullscreen_exit', 0, type=int)
        attempt.violation_tab_switch = max(tab_f, attempt.violation_tab_switch or 0)
        attempt.violation_copy = copy_f or (attempt.violation_copy or False)
        attempt.violation_fullscreen_exit = max(fs_f, attempt.violation_fullscreen_exit or 0)

    lab_file_id = attempt.password.file_id
    correct_map = {
        fqa.question_id: fqa.correct_answer
        for fqa in FileQuestionAnswer.query.filter_by(lab_file_id=lab_file_id)
    }

    score = 0
    results = []
    for ans_rec in attempt.answers:
        q = ans_rec.question
        ans_text = request.form.get(f"q{q.id}", "").strip()
        correct = (correct_map.get(q.id) or "").strip()
        is_correct = ans_text.lower() == correct.lower()
        if is_correct:
            score += 1
        results.append(['neutral', q.text])   # never reveal correct/wrong
        ans_rec.answer_text = ans_text
        ans_rec.is_correct = is_correct

    attempt.score = score
    attempt.finished_at = datetime.now(MSK)
    attempt.watermark_hash = generate_watermark_hash(attempt)
    db.session.commit()

    session.pop('active_attempt_id', None)
    return render_template("public/finish.html", attempt=attempt, answers=results)


# ---------------------------------------------------------------------------
# Auto-finish (client timer expiry)
# ---------------------------------------------------------------------------
@public_bp.route("/auto-finish/<int:attempt_id>", methods=["POST"])
def auto_finish(attempt_id):
    if not validate_csrf_token():
        abort(403)
    if session.get('active_attempt_id') != attempt_id:
        abort(403)

    attempt = Attempt.query.get_or_404(attempt_id)
    if attempt.finished_at is not None:
        return jsonify({'status': 'already_finished'})

    # Verify on server that time truly expired (client cannot fake this)
    expired, remaining = _check_time_expired(attempt, attempt.lab)
    if not expired and remaining is not None and remaining > 30:
        return jsonify({'status': 'not_expired', 'remaining': remaining})

    if attempt.lab.is_test:
        tab_f = request.form.get('violation_tab_switch', 0, type=int)
        copy_f = request.form.get('violation_copy', '0') == '1'
        fs_f = request.form.get('violation_fullscreen_exit', 0, type=int)
        attempt.violation_tab_switch = max(tab_f, attempt.violation_tab_switch or 0)
        attempt.violation_copy = copy_f or (attempt.violation_copy or False)
        attempt.violation_fullscreen_exit = max(fs_f, attempt.violation_fullscreen_exit or 0)

    attempt.score = 0
    attempt.finished_at = datetime.now(MSK)
    attempt.watermark_hash = generate_watermark_hash(attempt)
    db.session.commit()
    session.pop('active_attempt_id', None)

    return jsonify({'status': 'success',
                    'message': 'Время вышло, работа завершена автоматически'})
