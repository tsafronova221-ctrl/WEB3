import os
import hashlib

from flask import render_template, request, redirect, url_for
from flask_login import login_user, logout_user, login_required, UserMixin

from .__blueprint__ import auth_bp
from app.csrf import validate_csrf_token
from app import login_manager


def _hash(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


# Passwords are loaded from environment variables.
# Set them before running: export ADMIN_PASSWORD="..." TEACHER_PASSWORD="..."
_ADMIN_HASH = os.environ.get('ADMIN_PASSWORD_HASH') or _hash(
    os.environ.get('ADMIN_PASSWORD', 'CHANGE_ME')
)
_TEACHER_HASH = os.environ.get('TEACHER_PASSWORD_HASH') or _hash(
    os.environ.get('TEACHER_PASSWORD', 'CHANGE_ME_TOO')
)

USERS: dict[str, str] = {
    "admin": _ADMIN_HASH,
    "teacher": _TEACHER_HASH,
}


class SimpleUser(UserMixin):
    def __init__(self, username):
        self.id = username


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not validate_csrf_token():
            from flask import abort
            abort(403)
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        if username in USERS and USERS[username] == _hash(password):
            user = SimpleUser(username)
            login_user(user)
            return redirect(url_for("admin.index"))

        return render_template("admin/login.html", error="Неверный логин или пароль")

    return render_template("admin/login.html")


@auth_bp.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for("auth.login"))
