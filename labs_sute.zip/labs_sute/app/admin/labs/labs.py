import re
import base64
import os
from datetime import datetime

import pytz
from flask import render_template, request, jsonify

from .__blueprint__ import admin_labs_bp
from app import db
from app.models import Group, Lab, LabFile, Question, FileQuestionAnswer

MSK = pytz.timezone('Europe/Moscow')

_SAFE_FILENAME = re.compile(r'^[\w\-. ]+$')
_MAX_FILE_SIZE = 50 * 1024 * 1024  # 50 MB


def _sanitize_filename(name: str) -> str:
    """Strip directory components and reject dangerous filenames."""
    name = os.path.basename(name).strip()
    if not name or not _SAFE_FILENAME.match(name):
        raise ValueError(f"Недопустимое имя файла: {name!r}")
    return name


def _safe_b64decode(b64_str: str) -> bytes:
    """Decode base64, stripping data-URL prefix if present."""
    if ',' in b64_str:
        b64_str = b64_str.split(',', 1)[1]
    data = base64.b64decode(b64_str)
    if len(data) > _MAX_FILE_SIZE:
        raise ValueError("Файл слишком большой (макс. 50 МБ)")
    return data


@admin_labs_bp.route("/create_labs")
def create_labs():
    groups = Group.query.all()
    return render_template("admin/edit_labs.html", groups=groups)


@admin_labs_bp.route("/create_lab", methods=["POST"])
def create_lab():
    data = request.json

    lab_name = data['name']
    deadline = data['deadline']
    start_date = data['start_date']
    description = data['description']
    group_ids = [int(g) for g in data['groups']]
    files = data['files']
    questions = data['questions']
    is_test = data.get('is_test', False)
    questions_count = int(data.get('questions_count', 0))

    start_dt = datetime.fromisoformat(start_date)
    deadline_dt = datetime.fromisoformat(deadline)

    if start_dt.tzinfo is None:
        start_dt = MSK.localize(start_dt).replace(tzinfo=None)
    if deadline_dt.tzinfo is None:
        deadline_dt = MSK.localize(deadline_dt).replace(tzinfo=None)

    lab = Lab(
        title=lab_name,
        code=f"LAB-{int(datetime.now(MSK).timestamp())}",
        description=description,
        start_at=start_dt,
        deadline_at=deadline_dt,
        is_test=is_test,
        questions_count=questions_count,
        test_duration=int(data.get('test_duration', 0)),
    )

    if group_ids:
        lab.groups = Group.query.filter(Group.id.in_(group_ids)).all()

    db.session.add(lab)
    db.session.flush()

    lab_files = []
    files_dir = os.path.join("instance", "labs", str(lab.id))
    os.makedirs(files_dir, exist_ok=True)

    for f in files:
        try:
            safe_name = _sanitize_filename(f['name'])
            content = _safe_b64decode(f['base64'])
        except ValueError as exc:
            return jsonify({'success': False, 'error': str(exc)}), 400

        file_path = os.path.join(files_dir, safe_name)
        # Final path-traversal guard
        abs_base = os.path.abspath(files_dir)
        abs_path = os.path.abspath(file_path)
        if not abs_path.startswith(abs_base + os.sep):
            return jsonify({'success': False, 'error': 'Недопустимый путь файла'}), 400

        with open(file_path, "wb") as fp:
            fp.write(content)

        lf = LabFile(lab_id=lab.id, file_path=file_path)
        db.session.add(lf)
        lab_files.append(lf)

    db.session.flush()

    question_objs = []
    for q in questions:
        q_obj = Question(lab_id=lab.id, text=q['text'])
        db.session.add(q_obj)
        question_objs.append(q_obj)

    db.session.flush()

    for q, q_obj in zip(questions, question_objs):
        for ans in q.get('answers', []):
            file_index = ans['file_index']
            if file_index < 0 or file_index >= len(lab_files):
                continue
            fqa = FileQuestionAnswer(
                lab_file_id=lab_files[file_index].id,
                question_id=q_obj.id,
                correct_answer=ans['correct_answer'].strip(),
            )
            db.session.add(fqa)

    db.session.commit()
    return jsonify({'success': True})
