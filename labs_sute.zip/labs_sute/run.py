# -*- coding: utf-8 -*-
from app import create_app
import os

if __name__ == "__main__":
    app = create_app()
    # Debug mode is controlled by the FLASK_DEBUG environment variable.
    # Never run with debug=True in production!
    debug = os.environ.get('FLASK_DEBUG', 'false').lower() == 'true'
    app.run(host="0.0.0.0", port=5000, debug=debug)